# aws_rds_playbook

## Basic installation of a RDS instance in AWS
## Check ansible modules for any changes
