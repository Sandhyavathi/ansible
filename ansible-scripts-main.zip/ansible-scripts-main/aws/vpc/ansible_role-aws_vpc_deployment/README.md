# ansible-aws_vpc-deployment
#Enter your aws credentials here "aws-vpc/vars/main.yml"
#Run the playbook file "vpc.yml"
#Playbook is written in YAML

#Deploy a Virtual Private Cloud using Ansible 
#Created a role aws-vpc which will launch a VPC with basic settings
#For modules please refer ansible modules
https://docs.ansible.com/ansible/latest/modules/modules_by_category.html
