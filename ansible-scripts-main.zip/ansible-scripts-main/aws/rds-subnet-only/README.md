# aws_rds_subnet_group_playbook
create a RDS subnet group using ansible playbook
